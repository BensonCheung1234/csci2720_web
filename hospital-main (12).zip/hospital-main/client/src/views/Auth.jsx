import React, { Component } from "react";
import axios from "axios";
import CryptoJS from "crypto-js";
import { Redirect } from "react-router-dom";

export default class User extends Component {
  constructor() {
    super();
  }

  render() {
    return (
      <div>
        <h1>USER PAGE</h1>
        <Auth />
      </div>
    );
  }
}

class Auth extends Component {
  constructor(props) {
    super(props);
    let url = "http://csci2720-g28.cse.cuhk.edu.hk";
    axios.get(`${url}/db/hospitals`).then((response) => {
      response.data.forEach((item) => {
        console.log(item);
      });
    });

    this.state = { usr: "", pwd: "", username: null };
    this.onSubmit = this.onSubmit.bind(this);
    this.onChange1 = this.onChange1.bind(this);
    this.onChange2 = this.onChange2.bind(this);
  }

  onChange1(event) {
    this.setState({
      usr: event.target.value,
    });
  }

  onChange2(event) {
    this.setState({
      pwd: event.target.value,
    });
  }

  onSubmit(event) {
    let flag = true;
    axios({
      method: "GET",
      url: "http://csci2720-g28.cse.cuhk.edu.hk/db/users",
    })
      .then((response) => {
        response.data.forEach((item) => {
          if (item.username.match(this.state.usr)) {
            let temp = CryptoJS.SHA256(this.state.pwd);
            if (item.password.match(temp)) {
              flag = false;
              window.localStorage.setItem("username", item.username);

              this.setState({ username: item.username });
            }
          }
        });
      })
      .then(() => {
        if (flag) {
          alert("WRONG CREDENTIALS");
        }
        this.setState({ usr: "", pwd: "" });
      });

    event.preventDefault();
  }

  render() {
    if (this.state.username) {
      console.log(this.state.username);
      return <Redirect to="/home" />;
    }
    return (
      <div className="panel">
        <form className="loginform" onSubmit={this.onSubmit}>
          <h1>LOGIN FORM</h1>
          <p>
            <label htmlFor="username">username</label>
            <input
              type="username"
              name="username"
              value={this.state.usr}
              onChange={this.onChange1}
            />
          </p>
          <p>
            <label htmlFor="password">password</label>
            <input
              type="password"
              name="password"
              value={this.state.pwd}
              onChange={this.onChange2}
            />
          </p>
          <input type="submit" />
        </form>
      </div>
    );
  }
}
