import React, { Component } from "react";
import axios from "axios";

export default class Admin extends Component {
  constructor() {
    super();
  }

  render() {
    return (
      <div>
        <h1>ADMIN PAGE</h1>
        <Auth />
      </div>
    );
  }
}

class Auth extends Component {
  constructor(props) {
    super(props);
    this.state = { name: "", time: "", x: "", y: "" };
    this.onChange1 = this.onChange1.bind(this);
    this.onChange2 = this.onChange2.bind(this);
    this.onChange3 = this.onChange3.bind(this);
    this.onChange4 = this.onChange4.bind(this);
  }

  onChange1(event) {
    this.setState({
      name: event.target.value,
    });
  }

  onChange2(event) {
    this.setState({
      time: event.target.value,
    });
  }

  onChange3(event) {
    this.setState({
      x: event.target.value,
    });
  }

  onChange4(event) {
    this.setState({
      y: event.target.value,
    });
  }

  create(event) {
    event.preventDefault();
    let url = "http://csci2720-g28.cse.cuhk.edu.hk";
    let obj = {
      name: this.state.name,
      time: this.state.time,
      coordiantes: [this.state.x, this.state.y],
    };
    axios({
      method: "POST",
      url: `${url}/db/hospitals`,
      data: obj,
    });
  }

  update(event) {
    event.preventDefault();
  }

  delete(event) {
    event.preventDefault();
  }

  render() {
    function refreshData() {
      console.log("HI");
    }

    let url = "http://csci2720-g28.cse.cuhk.edu.hk";
    var rows = [];
    axios
      .get(`${url}/db/hospitals`)
      .then((response) => {
        response.data.forEach((item) => {
          rows.push(item);
        });
      })
      .then(() => {
        console.log(rows);
      });

    return (
      <div className="panel">
        <button onClick={refreshData}>Refresh Data</button>

        <form className="admin">
          <h3>Hopistal Name</h3>
          <input
            type="text"
            value={this.state.name}
            onChange={this.onChange1}
          ></input>

          <h3>Waiting Time</h3>
          <input
            type="text"
            value={this.state.time}
            onChange={this.onChange2}
          ></input>

          <h3>Coordinates</h3>
          <input
            type="text"
            value={this.state.x}
            onChange={this.onChange3}
          ></input>
          <input
            type="text"
            value={this.state.y}
            onChange={this.onChange4}
          ></input>

          <p>
            <button onClick={this.create}>CREATE</button>
            <button onClick={this.update}>UPDATE</button>
            <button onClick={this.delete}>DELETE</button>
          </p>
        </form>
      </div>
    );
  }
}
