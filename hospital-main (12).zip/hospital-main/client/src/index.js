import React from 'react';
import ReactDOM from 'react-dom';
import 'mapbox-gl/dist/mapbox-gl.css';

import './stylesheet.scss';
import App from './App.jsx';

ReactDOM.render(
  <>
    <App />
  </>,
  document.getElementById('root')
);
