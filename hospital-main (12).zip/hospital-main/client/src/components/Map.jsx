import React from "react";

import mapboxgl from "!mapbox-gl"; // eslint-disable-line import/no-webpack-loader-syntax

mapboxgl.accessToken =
  "pk.eyJ1IjoiYmVuc29uMTIzNDAwMDAiLCJhIjoiY2tvY21uenNrMXEzNDJ1bXFlY2twbGVheCJ9.zxVDGk0DlGK0GK7G7GXxAg";

var hospital = [
  {
    id: 1,
    name: "Alice Ho Miu Ling Nethersole Hospital",
    time: "Over 1 hour",
    coordinates: [114.17490164272516, 22.458495869828894],
  },
  {
    id: 2,
    name: "Caritas Medical Centre",
    time: "Over 3 hours",
    coordinates: [114.1531916, 22.3414653],
  },
  {
    id: 3,
    name: "Kwong Wah Hospital",
    time: "Over 3 hours",
    coordinates: [114.1724134, 22.3151818],
  },
  {
    id: 4,
    name: "North District Hospital",
    time: "Over 4 hours",
    coordinates: [114.1246908, 22.4968697],
  },
  {
    id: 5,
    name: "North Lantau Hospital",
    time: "Around 1 hour",
    coordinates: [113.9392707, 22.2820281],
  },
  {
    id: 6,
    name: "Princess Margaret Hospital",
    time: "Over 2 hours",
    coordinates: [114.1316326, 22.341361],
  },
  {
    id: 7,
    name: "Pok Oi Hospital",
    time: "Over 1 hour",
    coordinates: [114.0419062, 22.4454026],
  },
  {
    id: 8,
    name: "Prince of Wales Hospital",
    time: "Over 7 hour",
    coordinates: [114.201222, 22.378404],
  },
  {
    id: 9,
    name: "Pamela Youde Nethersole Eastern Hospital",
    time: "Over 6 hour",
    coordinates: [114.2362653, 22.2695993],
  },
  {
    id: 10,
    name: "Queen Elizabeth Hospital",
    time: "Over 2 hour",
    coordinates: [114.1746325, 22.3088961],
  },
];

export default class Map extends React.PureComponent {
  constructor(props) {
    super(props);

    // PERFECT COORDIANTES TO SHOW HONG KONG MAP
    this.state = {
      lng: 114.1201,
      lat: 22.369,
      zoom: 10.11,
    };
    this.mapContainer = React.createRef();
  }

  componentDidMount() {
    //get access to the dynamic Id being passed into our route, but not working

    // const { match: { params } } = this.props;

    // axios.get(`/detail/${params.id}`)
    // .then(({ data: mapData }) => {
    // console.log('Map ID', mapData);

    // this.setState({ mapData });
    //  });

    const { lng, lat, zoom } = this.state;
    const map = new mapboxgl.Map({
      container: this.mapContainer.current,
      style: "mapbox://styles/mapbox/streets-v11",
      center: [lng, lat],
      zoom: zoom,
    });
    map.on("move", () => {
      this.setState({
        lng: map.getCenter().lng.toFixed(4),
        lat: map.getCenter().lat.toFixed(4),
        zoom: map.getZoom().toFixed(2),
      });
    });

    for (var i = 0; i < 10; i++) {
      // create the popup
      var popup = new mapboxgl.Popup({ offset: 25 }).setText(hospital[i].name);

      // create DOM element for the marker
      var el = document.createElement("div");
      el.id = "marker";

      // create the marker
      new mapboxgl.Marker(el)
        .setLngLat(hospital[i].coordinates)
        .setPopup(popup) // sets a popup on this marker
        .addTo(map);
    }

    // zoom in to one place
    // for(var j = 0;i<10;i++){
    // if( xxx.id == hospital[j].id){
    //   map.on('move', () => {
    //     this.setState({
    //     lng: hospital[i].coordinates[0],
    //     lat: hospital[i].coordinates[1],
    //     zoom: 15.4
    //     });
    //     });

    // }
    // }
  }

  render() {
    return <div ref={this.mapContainer} className="map-container"></div>;
  }
}
