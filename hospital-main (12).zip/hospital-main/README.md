# CSCI2720 - HOSPITAL

## HOW TO RUN

0. ```cd client``` or ```cd server```
1. ```npm install```
2. ```npm start```

## PORTS

- client: 8080
- server: 2028


We have read http://www.cuhk.edu.hk/policy/academichonesty
