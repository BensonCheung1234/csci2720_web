import React, { Component } from "react";

import Map from "../components/Map";
import Datatable from "../components/Datatable";
import axios from "axios";

export default class Home extends Component {
  constructor() {
    super();

    let url = "http://csci2720-g28.cse.cuhk.edu.hk";
    axios.get(`${url}/db/hospitals`).then((response) => {
      console.log(response);
    });
  }

  render() {
    return (
      <div>
        <h1>HOME PAGE</h1>
        <Map />
        <h3>ALL HOSPITALS</h3>
        <Datatable />
      </div>
    );
  }
}
