import React, { Component } from "react";
import Favourite from "../components/Favourite";
import { Redirect } from "react-router-dom";

export default class User extends Component {
  constructor(props) {
    super(props);
    this.logout = this.logout.bind(this);
    this.state = { flag: false };
  }

  logout() {
    console.log(1);
    window.localStorage.clear();
    this.setState({ flag: true });
  }

  render() {
    if (this.state.flag) {
      return <Redirect to="/" />;
    }
    return (
      <div>
        <h1>USER PAGE</h1>
        <div className="panel">
          <button onClick={this.logout}>LOGOUT</button>
        </div>
        <h2>favorite</h2>
        <Favourite />
      </div>
    );
  }
}
