import React from "react";
import { Button } from "@material-ui/core";
import { DataGrid, GridApi, GridCellValue } from "@material-ui/data-grid";

import axios from "axios";

var columns = [
  {
    field: "name",
    headerName: "Hospital Name",
    width: 450,
  },
  {
    field: "time",
    headerName: "Waiting Time",
    width: 200,
  },
  {
    field: "",
    sortable: false,
    width: 100,
    disableColumnMenu: true,
    renderCell: (params) => {
      const onClick = () => {
        const api: GridApi = params.api;
        const fields = api
          .getAllColumns()
          .map((c) => c.field)
          .filter((c) => c !== "__check__" && !!c);
        const row: Record<string, GridCellValue> = {};

        fields.forEach((f) => {
          row[f] = params.getValue(f);
        });

        return console.log(row); // ALERT ID Number
      };

      return <Button onClick={onClick}>→</Button>;
    },
  },
];
var rowsa = [{ id: 0, name: 0, time: 0 }];

function setData(id: number, name: string, time: string) {
  return { id, name, time };
}

let url = "http://csci2720-g28.cse.cuhk.edu.hk";
var rows = [];
fetch(`${url}/api`)
  .then((response) => response.json())
  .then((dataJson) => {
    for (var i = 0; i < 5; i++) {
      rows[i] = setData(
        i + 1,
        dataJson.waitTime[i].hospName,
        dataJson.waitTime[i].topWait
      );

      //console.log(dataJson.waitTime[i].hospName)
    }
    console.log(rows);
  });

export default class HospitalTable extends React.PureComponent {
  constructor() {
    super();
    this.state = { rows: rows };
  }

  componentDidMount() {}

  render() {
    return (
      // USING <DataGrid>
      <>
        <div className="datagrid">
          <DataGrid rows={this.state.rows} columns={columns} pageSize={10} />
        </div>
      </>
    );
  }
}
