import React, { Component } from "react";
import { BrowserRouter, Switch, Route, Link, Redirect } from "react-router-dom";

import Home from "./views/Home";
import Hospital from "./views/Hospital";
import User from "./views/User";
import Admin from "./views/Admin";
import Auth from "./views/Auth";

var username = null;

export default class App extends Component {
  constructor() {
    super();
    this.state = { username: window.localStorage.getItem("username") };
  }
  render() {
    if (username) {
      username = (
        <Link to="/" className="link">
          LOGIN
        </Link>
      );
    }
    return (
      <div className="app">
        <h1>CSCI2720 GROUP 8</h1>
        <BrowserRouter>
          <div className="navbar">
            <p>
              <Link to="/home" className="link">
                HOME
              </Link>
            </p>
            |
            <p>
              <Link to="/user" className="link">
                USER PAGE
              </Link>
            </p>
            |
            <p>
              <Link to="/admin" className="link">
                ADMIN PAGE
              </Link>
            </p>
            <p className="username">{username}</p>
          </div>

          <Switch>
            <Route exact path={"/"} render={(props) => <Auth />} />
            <Route path={"/home"} render={(props) => <Home />} />
            <Route
              path={"/hospital/:id"}
              render={(props) => <Hospital {...props} />}
            />
            <Route path={"/user"} render={(props) => <User />} />
            <Route path={"/admin"} render={(props) => <Admin />} />
            <Route path={"/auth"} render={(props) => <Auth />} />
          </Switch>
        </BrowserRouter>
      </div>
    );
  }
}
