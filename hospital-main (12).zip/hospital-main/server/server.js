const express = require("express");
const request = require("request");
const app = express();

const cors = require("cors");

var mongoose = require("mongoose");
mongoose.connect("mongodb://s1155109312:x70573@localhost/s1155109312");

var bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  next();
});

app.use(cors());

var UserSchema = mongoose.Schema({
  username: { type: String, required: true },
  password: { type: String, required: true },
});
var User = mongoose.model("User", UserSchema);

var HospitalSchema = mongoose.Schema({
  name: { type: String, required: true },
  time: { type: String, required: true },
  coordinates: [{ type: Number, required: true }],
});
var Hospital = mongoose.model("Hospital", HospitalSchema);

var CommentSchema = mongoose.Schema({
  user: { type: String, required: true },
  content: { type: String, required: true },
});
var Comment = mongoose.model("Comment", CommentSchema);

app.get("/api", (req, res) => {
  const date = req.query["date"];
  const time = req.query["time"];
  const url = `https://www.ha.org.hk/opendata/aed/aedwtdata-en.json`;
  if (time || date) {
    const url = `https://www.ha.org.hk/opendata/aed/aedwtdata-en.json`;
  }
  request(url).pipe(res);
});

app.get("/db/hospitals", (req, res) => {
  Hospital.find({}, (err, data) => {
    res.json(data);
  });
});

app.post("/db/hospitals", (req, res) => {
  let coordiantes = [req.body["x"], req.body["y"]];
  var obj = new Hospital({
    name: req.body["name"],
    time: req.body["time"],
    coordinates: coordinates,
  });
  obj.save((err) => {
    if (err) res.send(err);
  });
});

app.put("/db/hospitals/:id", (req, res) => {
  var obj = {};
  Hospital.findOne({ _id: req.params["id"] }, (req, res) => {
    obj = req;
  });
  if (req.body["name"]) obj.name = req.body["name"];
  if (req.body["time"]) obj.time = req.body["time"];
  if (req.body["x"] && req.body["y"]) {
    let coordiantes = [req.body["x"], req.body["y"]];
    obj.coordinates = coordiantes;
  }

  Hospital.updateOne({ _id: req.params["id"], obj }, (err) => {
    if (err) res.json(data);
  });
});

app.delete("/db/hospitals", (req, res) => {
  // Hospital.find({}, (err, data) => {
  //   res.json(data);
  // });
});

app.get("/db/users", (req, res) => {
  User.find({}, (err, data) => {
    res.json(data);
  });
});

app.post("/db/users", (req, res) => {
  var obj = new User({
    username: req.body["username"],
    password: req.body["password"],
  });
  obj.save((err) => {
    if (err) res.send(err);
  });
});

app.get("/db/comments", (req, res) => {
  Comment.find({}, (err, data) => {
    res.json(data);
  });
});

const server = app.listen(2028);
