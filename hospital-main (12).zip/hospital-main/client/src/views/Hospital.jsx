import React, { Component } from "react";
import Map from "./MapForHospital";

var hospital = [
  {
    id: 1,
    name: "Alice Ho Miu Ling Nethersole Hospital",
    time: "Over 1 hour",
    coordinates: [114.17490164272516, 22.458495869828894],
  },
  {
    id: 2,
    name: "Caritas Medical Centre",
    time: "Over 3 hours",
    coordinates: [114.1531916, 22.3414653],
  },
  {
    id: 3,
    name: "Kwong Wah Hospital",
    time: "Over 3 hours",
    coordinates: [114.1724134, 22.3151818],
  },
  {
    id: 4,
    name: "North District Hospital",
    time: "Over 4 hours",
    coordinates: [114.1246908, 22.4968697],
  },
  {
    id: 5,
    name: "North Lantau Hospital",
    time: "Around 1 hour",
    coordinates: [113.9392707, 22.2820281],
  },
  {
    id: 6,
    name: "Princess Margaret Hospital",
    time: "Over 2 hours",
    coordinates: [114.1316326, 22.341361],
  },
  {
    id: 7,
    name: "Pok Oi Hospital",
    time: "Over 1 hour",
    coordinates: [114.0419062, 22.4454026],
  },
  {
    id: 8,
    name: "Prince of Wales Hospital",
    time: "Over 7 hour",
    coordinates: [114.201222, 22.378404],
  },
  {
    id: 9,
    name: "Pamela Youde Nethersole Eastern Hospital",
    time: "Over 6 hour",
    coordinates: [114.2362653, 22.2695993],
  },
  {
    id: 10,
    name: "Queen Elizabeth Hospital",
    time: "Over 2 hour",
    coordinates: [114.1746325, 22.3088961],
  },
];

var display = [];
export default class Hospital extends Component {
  constructor() {
    super();
  }

  render() {
    // for(var i = 0;i<10;i++){
    //   if (id == hospital[i].id){
    //     display = hospital[i];
    //   }
    // }
    display = hospital[this.props.match.params.id];

    return (
      <div>
        <h1>{display.name}</h1>
        <p>{display.time}</p>
        <Map id={this.props.match.params.id} />
        <button>Add to favoutite place</button>
        <h1>h1h1 {this.props.match.params.id}</h1>
      </div>
    );
  }
}
